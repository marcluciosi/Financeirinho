package com.ls.financerinho10.telas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ls.financerinho10.R;
import com.ls.financerinho10.listadealunos.Kaique;
import com.ls.financerinho10.listadealunos.Luiz;
import com.ls.financerinho10.listadealunos.Marcelo;
import com.ls.financerinho10.listadealunos.Matheus;
import com.ls.financerinho10.listadealunos.Tarcisio;
import com.ls.financerinho10.listadealunos.Tharcyl;


public class Pontuacao extends AppCompatActivity {
    ListView listpont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pontuacao);

        listpont = findViewById(R.id.listpont);

        String[] values = new String[]{
                "1- Luiz", "2- Marcelo", "3- Matheus", "4- Tharcyl", "5- Tarcisio", "6- Kaique"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1, values);

        listpont.setAdapter(adapter);

        listpont.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0){
                    Intent intent = new Intent(view.getContext(), Luiz.class);
                    startActivity(intent);
                }

                if (position == 1){
                    Intent intent = new Intent(view.getContext(), Marcelo.class);
                    startActivity(intent);
                }

                if (position == 2){
                    Intent intent = new Intent(view.getContext(), Matheus.class);
                    startActivity(intent);
                }

                if (position == 3){
                    Intent intent = new Intent(view.getContext(), Tharcyl.class);
                    startActivity(intent);
                }

                if (position == 4){
                    Intent intent = new Intent(view.getContext(), Tarcisio.class);
                    startActivity(intent);
                }

                if (position == 5){
                    Intent intent = new Intent(view.getContext(), Kaique.class);
                    startActivity(intent);

                }
            }
        });


    }
}