package com.ls.financerinho10.listadealunos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ls.financerinho10.R;

public class Tarcisio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarcisio);
    }
}