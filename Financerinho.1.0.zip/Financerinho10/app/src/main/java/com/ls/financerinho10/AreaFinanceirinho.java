package com.ls.financerinho10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.ls.financerinho10.telas.IntroGame;
import com.ls.financerinho10.telas.Pontuacao;

public class AreaFinanceirinho extends AppCompatActivity {

    private ImageButton bgame, bmentoria, bpontuacao, bturma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_financeirinho);

        bgame = (ImageButton) findViewById(R.id.bgame);
        bmentoria = (ImageButton) findViewById(R.id.bmentoria);
        bpontuacao = (ImageButton) findViewById(R.id.bpontuacao);
        bturma= (ImageButton) findViewById(R.id.bturma);

        bgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bgameActivity();

            }
        });

        bmentoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bmentoriaActivity();
            }
        });

        bpontuacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bpontuacaoActivity();
            }
        });

        bturma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bturmaActivity();
            }
        });

    }

    private void bturmaActivity() {
        startActivity(new Intent( AreaFinanceirinho.this, IntroGame.class));
    }

    private void bmentoriaActivity() {
        startActivity(new Intent( AreaFinanceirinho.this, Mentoria.class));
    }

    private void bpontuacaoActivity() {
        startActivity(new Intent( AreaFinanceirinho.this, Pontuacao.class));
    }


    private void bgameActivity() {

        startActivity(new Intent( AreaFinanceirinho.this, IntroGame.class));

    }



}

