package com.ls.financerinho10.telas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.ls.financerinho10.QuestaoModel;
import com.ls.financerinho10.R;

import java.util.ArrayList;
import java.util.List;

public class Game extends AppCompatActivity {


    private TextView   tvScore, tvQuestionCount, tvViewQuestion, tvViewCountdown;
    private RadioGroup radiogroup;
    private RadioButton radioButton1, radioButton2, radioButton3;
    private Button buttonConfirmNext;

    int score;
    int totalQuestions;
    int qCounter = 0;


    ColorStateList dfRbColor;
    boolean answered;

    CountDownTimer countDownTimer;


    private QuestaoModel currentQuestion;


    private List<QuestaoModel> questaolist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        questaolist = new ArrayList<>();
        tvScore = findViewById(R.id.text_view_score);
        tvQuestionCount = findViewById(R.id.text_view_question_count);
        tvViewQuestion = findViewById(R.id.text_view_question);
        tvViewCountdown = findViewById(R.id.text_view_countdown);

        radiogroup = findViewById(R.id.radio_group);
        radioButton1 = findViewById(R.id.radio_button1);
        radioButton2 = findViewById(R.id.radio_button2);
        radioButton3 = findViewById(R.id.radio_button3);
        buttonConfirmNext = findViewById(R.id.button_confirm_next);

        dfRbColor = radioButton1.getTextColors();

        addQuestaos();
        totalQuestions = questaolist.size();
        showNextQuestao();

        buttonConfirmNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(answered == false){
                    if (radioButton1.isChecked()  || radioButton2.isChecked()  || radioButton3.isChecked()){
                        checkAnswer();
                        countDownTimer.cancel();


                    }else {
                        Toast.makeText(Game.this, "Por favor selecione uma opção", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    showNextQuestao();
                }
            }
        });
    }

    private void checkAnswer() {
        answered = true;
        RadioButton rbSelected = findViewById(radiogroup.getCheckedRadioButtonId());
        int answerNo = radiogroup.indexOfChild(rbSelected) + 1;
        if(answerNo == currentQuestion.getCorreta()){
            score++;
            tvScore.setText("Ponto: "+score);

        }
        radioButton1.setTextColor(Color.RED);
        radioButton2.setTextColor(Color.RED);
        radioButton3.setTextColor(Color.RED);
        switch (currentQuestion.getCorreta()){
            case 1:
                radioButton1.setTextColor(Color.GREEN);
                break;
            case 2:
                radioButton2.setTextColor(Color.GREEN);
                break;
            case 3:
                radioButton3.setTextColor(Color.GREEN);
                break;
        }
        if(qCounter < totalQuestions){
            buttonConfirmNext.setText("Próxima");
        }else {
            buttonConfirmNext.setText("Fim");
        }


    }

    private void showNextQuestao() {

        radiogroup.clearCheck();
        radioButton1.setTextColor(dfRbColor);
        radioButton2.setTextColor(dfRbColor);
        radioButton3.setTextColor(dfRbColor);


        if (qCounter < totalQuestions){
                countDownTimer();
                currentQuestion = questaolist.get(qCounter);
                tvViewQuestion.setText(currentQuestion.getQuestao());
                radioButton1.setText(currentQuestion.getOpcao1());
                radioButton2.setText(currentQuestion.getOpcao2());
                radioButton3.setText(currentQuestion.getOpcao3());


                qCounter++;
                buttonConfirmNext.setText("Próxima");
                tvQuestionCount.setText("Questão: "+qCounter+"/"+totalQuestions);
                answered = false;

        }else {
            finish();
        }

    }

    private void countDownTimer() {
        countDownTimer = new CountDownTimer(20000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                tvViewCountdown.setText("00:" + millisUntilFinished/1000);
            }

            @Override
            public void onFinish() {
                showNextQuestao();
            }
        }.start();
    }

    private void addQuestaos() {

        questaolist.add(new QuestaoModel("1 - Junior ja tendo ja vários  jogos em casa sem utilizar, juntou dinheiro e comprou mais alguns. No final do Mês ele percebeu que não estava usando. Junior em vez de gastar dinheiro, ele poderia ter feito:", "Separado os jogos que não usa mais dos que usa frequentemente, e vendido, feito uma doação ou trocar por novos jogos.", "Ter comprado mais jogos", "Não ter feito nada.",1));
        questaolist.add(new QuestaoModel("2- Assinale a alternativa que não apresenta uma moeda NÃO existente.", "Real", "Leni", "Dólar",2));
        questaolist.add(new QuestaoModel("3- Sobre educação financeira, porque devemos poupar? é a correta", "Não é fundamental aprendermos a poupar", "É fundamental pata comprrmos cada vez mais e sem invetir", "É fundamental para se precaver de eventos inesperados e planejar melhor o seu futuro",3));
        questaolist.add(new QuestaoModel("4- Com o dinheiro do lanche o que você faz:", " Guardo parte para realizar meus desejos e sonhos e o restante gasto em meu lanche.", "Gasto parte e a outra guardo para gastar depois da aula.", "Gasto tudo imediatamente, com doces e salgados.",1));
        questaolist.add(new QuestaoModel("5- Três quartos de uma quantia é R$ 120,00.Essa quantidade corresponde a ", "R$120,00", "R$90,00", "R$140,00",2));


    }
}